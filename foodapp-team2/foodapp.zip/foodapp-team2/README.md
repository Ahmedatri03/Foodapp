# FoodApp

Ceci est le projet de base pour l'UE Projet: initiation génie logiciel.

Vous devrez développer le logiciel de zéro afin de construire 
une application de recherche de recettes de cuisine.
